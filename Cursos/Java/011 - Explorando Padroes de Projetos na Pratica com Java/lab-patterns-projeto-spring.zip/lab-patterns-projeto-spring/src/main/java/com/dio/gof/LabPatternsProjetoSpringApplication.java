package com.dio.gof;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabPatternsProjetoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabPatternsProjetoSpringApplication.class, args);
	}

}

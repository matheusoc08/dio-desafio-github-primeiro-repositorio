package com.dio.gof;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabPatternsProjetoSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
